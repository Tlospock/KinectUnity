using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Kinect;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.Util;

namespace KinectWPFOpenCV
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        KinectSensor sensor;
        MultiSourceFrameReader reader;
        WriteableBitmap colorBitmap;
        byte[] colorPixels;

        int blobCount = 0;

        public MainWindow()
        {
            InitializeComponent();

            Loaded += MainWindow_Loaded;
            Closing += MainWindow_Closing;
            MouseDown += MainWindow_MouseDown;
        }


        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {

            sensor = KinectSensor.GetDefault();


            if (null != sensor)
            {
                reader = sensor.OpenMultiSourceFrameReader(FrameSourceTypes.Color | FrameSourceTypes.Depth);

                FrameDescription colorFD = sensor.ColorFrameSource.FrameDescription;

                colorPixels = new byte[colorFD.Width * colorFD.Height * ((PixelFormats.Bgr32.BitsPerPixel + 7) / 8)];
                colorBitmap = new WriteableBitmap(colorFD.Width, colorFD.Height, 96.0, 96.0, PixelFormats.Bgr32, null);
                colorImg.Source = colorBitmap;

                reader.MultiSourceFrameArrived += Sensor_AllFramesReady;

                sensor.Open();
            }
            else
            {
                outputViewbox.Visibility = Visibility.Collapsed;
                txtError.Visibility = Visibility.Visible;
                txtInfo.Text = "No Kinect Found";

            }

        }

        private void Sensor_AllFramesReady(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            MultiSourceFrame multiFrame = e.FrameReference.AcquireFrame();

            using (DepthFrame depthFrame = multiFrame.DepthFrameReference.AcquireFrame())
            {
                if (depthFrame != null)
                {

                    blobCount = 0;
                    ImageSource depthBmp = depthFrame.SliceDepthImage((ushort)sliderMin.Value, (ushort)sliderMax.Value);

                    Image<Bgr, byte> openCVImg = new Image<Bgr, byte>(depthBmp.ToBitmap()).Flip(Emgu.CV.CvEnum.FlipType.Horizontal);
                    Image<Gray, byte> gray_image = openCVImg.Convert<Gray, byte>();

                    //Find contours with no holes try CV_RETR_EXTERNAL to find holes
                    VectorOfVectorOfPoint contoursDectected = new VectorOfVectorOfPoint();
                    CvInvoke.FindContours(gray_image, contoursDectected, null, Emgu.CV.CvEnum.RetrType.List, Emgu.CV.CvEnum.ChainApproxMethod.ChainApproxSimple);


                    double minArea = Math.Pow(sliderMinSize.Value, 2);
                    double maxArea = Math.Pow(sliderMaxSize.Value, 2);
                    for (int i = 0; i < contoursDectected.Size; i++)
                    {
                        double area = CvInvoke.ContourArea(contoursDectected[i]);

                        if (minArea < area && area < maxArea)
                        {
                            RotatedRect rect = CvInvoke.MinAreaRect(contoursDectected[i]);
                            openCVImg.Draw(rect, new Bgr(System.Drawing.Color.Red), 2);
                            blobCount++;
                        }
                    }

                    //Grey levels only
                    outImg.Source = ImageHelpers.ToBitmapSource(openCVImg);
                    txtBlobCount.Text = blobCount.ToString();
                }


            }

            using (ColorFrame colorFrame = multiFrame.ColorFrameReference.AcquireFrame())
            {
                if (colorFrame != null)
                {
                    colorFrame.CopyConvertedFrameDataToArray(colorPixels, ColorImageFormat.Bgra);
                    colorBitmap.WritePixels(new Int32Rect(0, 0, colorBitmap.PixelWidth, colorBitmap.PixelHeight),
                        colorPixels, colorBitmap.PixelWidth * sizeof(int), 0);
                }
            }
        }


        #region Window Stuff
        void MainWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }


        void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (null != sensor)
            {
                sensor.Close();
            }
            if (reader != null)
            {
                reader.Dispose();
            }
        }

        private void CloseBtnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }
        #endregion
    }
}
